﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCBartenderApp.Models;

namespace MVCBartenderApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
// gives drinks an ID when added to OrderedDrinks List
        private static int drinkId = 0;
// OrderedDrinks List, holds ordered drinks
        public static List<DrinkMenu> OrderedDrinks = new List<DrinkMenu>();
// List that holds all drinks available to be ordered
        private static List<DrinkMenu> drink = new List<DrinkMenu>()
        {
            new DrinkMenu
            {
                Name = "Tequila Sunrise", Price = 5
            },
            new DrinkMenu
            {
                Name = "Rum & Coke", Price = 6
            },
            new DrinkMenu
            {
                Name = "Margarita", Price = 4
            }
        };

// should display the menu of drinks
        public IActionResult Index()
        {
            return View(drink);
        }

// should, when a drink is ordered: add it to OrderedDrinks List, give it an ID, and then redisplay menu
        public IActionResult DrinkOrder(DrinkMenu drink)
        {
            drink.drinkId = ++drinkId;
            OrderedDrinks.Add(drink);
            return View();
        }

        public IActionResult Privacy()
        {
            return RedirectToAction("Index");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
